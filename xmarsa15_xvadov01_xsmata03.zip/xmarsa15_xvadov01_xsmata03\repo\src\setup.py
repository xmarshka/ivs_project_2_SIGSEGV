from setuptools import setup

setup(
    name='Kalkulacka',
    version='1.0',
    packages=['Kalkulacka'],
    url='',
    license='',
    author='',
    author_email='',
    description=''
)
